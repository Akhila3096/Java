package com.cg.spring.jpa.springdata;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.service.IProductService;

@RestController
@ComponentScan(basePackages="com.cg.spring.jpa.springdata")
public class ProductController {
	
	@Autowired
	IProductService service;
	
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}
}

